HORTONWORKS DATA PLATFORM
HDP 2.1
Manual Install (RPM) - Helper Files

This package contains the following set of helper file for use when manually installing HDP via RPMs.

/scripts
   Set of scripts to set user, group and directory environment variables

/configuration_files
   Set of configuration files for Core Hadoop and Essential Hadoop components, including scripts for setting up monitoring.


Website - http://www.hortonworks.com
Documentation - http://docs.hortonworks.com/
Downloads - http://hortonworks.com/download/
Forums - http://hortonworks.com/community/forums/


Copyright 2012-2014 - Hortonworks, Inc.
