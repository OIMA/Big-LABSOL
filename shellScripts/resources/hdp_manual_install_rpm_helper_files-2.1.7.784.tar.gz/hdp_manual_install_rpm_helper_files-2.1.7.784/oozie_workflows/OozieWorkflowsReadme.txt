Hortonworks provides two, valid workflow.xml files that define Oozie actions. Use the following examples as templates to customize a workflow.xml file specific to your requirements.
- workflow_ex_hive_pig_actions.xml defines a hive action and a pig action.
- workflow_ex_fs.xml defines general fs actions.